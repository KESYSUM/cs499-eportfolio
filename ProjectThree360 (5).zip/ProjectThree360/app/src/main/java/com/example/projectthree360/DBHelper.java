package com.example.projectthree360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "projectthree360.db";
    private static final int DATABASE_VERSION = 6;
    private static final String TAG = "DBHelper";

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD_HASH = "password_hash";
    public static final String COLUMN_PASSWORD_SALT = "password_salt";

    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_ITEM_QUANTITY = "item_quantity";

    private static final int SALT_LENGTH = 16;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(getCreateUsersTableSql());
        db.execSQL(getCreateItemsTableSql());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 6) {
            migrateItemsTableWithQuantityConstraint(db);
        }
    }

    private String getCreateUsersTableSql() {
        return "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COLUMN_PASSWORD_HASH + " TEXT NOT NULL, "
                + COLUMN_PASSWORD_SALT + " TEXT NOT NULL)";
    }

    private String getCreateItemsTableSql() {
        return "CREATE TABLE IF NOT EXISTS " + TABLE_ITEMS + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT NOT NULL, "
                + COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL CHECK("
                + COLUMN_ITEM_QUANTITY + " >= 0))";
    }

    private void migrateItemsTableWithQuantityConstraint(SQLiteDatabase db) {
        db.beginTransaction();

        try {
            db.execSQL("ALTER TABLE " + TABLE_ITEMS + " RENAME TO items_old");
            db.execSQL(getCreateItemsTableSql());

            db.execSQL("INSERT INTO " + TABLE_ITEMS + " ("
                    + COLUMN_ITEM_ID + ", "
                    + COLUMN_ITEM_NAME + ", "
                    + COLUMN_ITEM_QUANTITY + ") SELECT "
                    + COLUMN_ITEM_ID + ", "
                    + COLUMN_ITEM_NAME + ", "
                    + COLUMN_ITEM_QUANTITY
                    + " FROM items_old WHERE "
                    + COLUMN_ITEM_NAME + " IS NOT NULL AND "
                    + COLUMN_ITEM_QUANTITY + " >= 0");

            db.execSQL("DROP TABLE items_old");
            db.setTransactionSuccessful();
            Log.d(TAG, "Items table migrated with quantity constraint");
        } catch (Exception e) {
            Log.e(TAG, "Items table migration failed", e);
        } finally {
            db.endTransaction();
        }
    }

    public boolean addUser(String username, String password) {
        if (username == null || password == null) {
            return false;
        }

        if (username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        String salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);

        if (hashedPassword == null) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username.trim());
        values.put(COLUMN_PASSWORD_HASH, hashedPassword);
        values.put(COLUMN_PASSWORD_SALT, salt);

        try {
            long result = db.insert(TABLE_USERS, null, values);

            if (result != -1) {
                Log.d(TAG, "User created: " + username.trim());
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.e(TAG, "User insert failed", e);
            return false;
        }
    }

    public boolean userExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username.trim()}
        )) {
            return cursor.getCount() > 0;
        } catch (Exception e) {
            Log.e(TAG, "User lookup failed", e);
            return false;
        }
    }

    public boolean checkUser(String username, String password) {
        if (username == null || password == null) {
            return false;
        }

        if (username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_PASSWORD_HASH + ", " + COLUMN_PASSWORD_SALT
                        + " FROM " + TABLE_USERS
                        + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username.trim()}
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }

            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD_HASH));
            String storedSalt = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD_SALT));
            String enteredHash = hashPassword(password, storedSalt);

            if (enteredHash == null) {
                return false;
            }

            return secureHashCompare(storedHash, enteredHash);
        } catch (Exception e) {
            Log.e(TAG, "Login check failed", e);
            return false;
        }
    }

    public boolean addItem(String itemName, int quantity) {
        if (!isValidItemData(itemName, quantity)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName.trim());
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        try {
            long result = db.insert(TABLE_ITEMS, null, values);

            if (result != -1) {
                Log.d(TAG, "Item added: " + itemName.trim());
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.e(TAG, "Item insert failed", e);
            return false;
        }
    }

    public boolean updateItem(int itemId, String itemName, int quantity) {
        if (itemId <= 0 || !isValidItemData(itemName, quantity)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName.trim());
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        try {
            int result = db.update(
                    TABLE_ITEMS,
                    values,
                    COLUMN_ITEM_ID + "=?",
                    new String[]{String.valueOf(itemId)}
            );

            if (result > 0) {
                Log.d(TAG, "Item updated: " + itemId);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.e(TAG, "Item update failed", e);
            return false;
        }
    }

    public boolean deleteItem(int itemId) {
        if (itemId <= 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        try {
            int result = db.delete(
                    TABLE_ITEMS,
                    COLUMN_ITEM_ID + "=?",
                    new String[]{String.valueOf(itemId)}
            );

            if (result > 0) {
                Log.d(TAG, "Item deleted: " + itemId);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.e(TAG, "Item delete failed", e);
            return false;
        }
    }

    public ArrayList<Item> getAllItems() {
        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " ORDER BY LOWER(" + COLUMN_ITEM_NAME + ") ASC, "
                        + COLUMN_ITEM_QUANTITY + " ASC",
                null
        )) {
            addCursorItemsToList(cursor, itemList);
        } catch (Exception e) {
            Log.e(TAG, "Item retrieval failed", e);
        }

        return itemList;
    }

    public ArrayList<Item> searchItemsByName(String searchText) {
        if (searchText == null || searchText.trim().isEmpty()) {
            return getAllItems();
        }

        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String searchPattern = "%" + searchText.trim() + "%";

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " WHERE " + COLUMN_ITEM_NAME + " LIKE ?"
                        + " ORDER BY LOWER(" + COLUMN_ITEM_NAME + ") ASC, "
                        + COLUMN_ITEM_QUANTITY + " ASC",
                new String[]{searchPattern}
        )) {
            addCursorItemsToList(cursor, itemList);
        } catch (Exception e) {
            Log.e(TAG, "Item search failed", e);
        }

        return itemList;
    }

    public ArrayList<Item> getLowStockItems(int threshold) {
        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " WHERE " + COLUMN_ITEM_QUANTITY + " <= ?"
                        + " ORDER BY " + COLUMN_ITEM_QUANTITY + " ASC, LOWER(" + COLUMN_ITEM_NAME + ") ASC",
                new String[]{String.valueOf(threshold)}
        )) {
            addCursorItemsToList(cursor, itemList);
        } catch (Exception e) {
            Log.e(TAG, "Low stock retrieval failed", e);
        }

        return itemList;
    }

    public int getTotalItemCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_ITEMS,
                null
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.e(TAG, "Item count failed", e);
        }

        return 0;
    }

    private void addCursorItemsToList(Cursor cursor, ArrayList<Item> itemList) {
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
                itemList.add(new Item(id, name, quantity));
            } while (cursor.moveToNext());
        }
    }

    private boolean isValidItemData(String itemName, int quantity) {
        return itemName != null && !itemName.trim().isEmpty() && quantity >= 0;
    }

    private String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            String saltedPassword = salt + password;
            byte[] hash = messageDigest.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e(TAG, "Password hashing failed", e);
            return null;
        }
    }

    private boolean secureHashCompare(String storedHash, String enteredHash) {
        if (storedHash == null || enteredHash == null) {
            return false;
        }

        byte[] storedBytes = storedHash.getBytes(StandardCharsets.UTF_8);
        byte[] enteredBytes = enteredHash.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(storedBytes, enteredBytes);
    }

    public static class Item {
        private final int id;
        private final String name;
        private final int quantity;

        public Item(int id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}