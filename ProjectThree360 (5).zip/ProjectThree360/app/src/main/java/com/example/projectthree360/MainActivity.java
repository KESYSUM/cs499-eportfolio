package com.example.projectthree360;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final int LOW_STOCK_THRESHOLD = 5;
    private static final int MAX_ITEM_NAME_LENGTH = 50;

    private DBHelper dbHelper;
    private GridView gridViewItems;
    private Button buttonAddItem;
    private Button buttonRequestSms;
    private Button buttonSearchItem;
    private Button buttonShowAllItems;
    private Button buttonShowLowStockItems;
    private EditText editPhoneNumber;
    private EditText editSearchItem;

    private ArrayList<DBHelper.Item> itemList;
    private ArrayList<String> displayList;
    private ArrayAdapter<String> adapter;

    private boolean smsPermissionGranted = false;

    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                smsPermissionGranted = isGranted;

                if (isGranted) {
                    Toast.makeText(MainActivity.this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "SMS permission denied. App still works without SMS.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);

        gridViewItems = findViewById(R.id.gridViewItems);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonRequestSms = findViewById(R.id.buttonRequestSms);
        buttonSearchItem = findViewById(R.id.buttonSearchItem);
        buttonShowAllItems = findViewById(R.id.buttonShowAllItems);
        buttonShowLowStockItems = findViewById(R.id.buttonShowLowStockItems);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editSearchItem = findViewById(R.id.editSearchItem);

        itemList = new ArrayList<>();
        displayList = new ArrayList<>();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        gridViewItems.setAdapter(adapter);

        checkCurrentSmsPermission();
        loadAllItems();

        buttonRequestSms.setOnClickListener(view -> requestSmsPermission());
        buttonAddItem.setOnClickListener(view -> showAddItemDialog());
        buttonSearchItem.setOnClickListener(view -> searchItems());
        buttonShowAllItems.setOnClickListener(view -> loadAllItems());
        buttonShowLowStockItems.setOnClickListener(view -> loadLowStockItems());

        gridViewItems.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < itemList.size()) {
                DBHelper.Item selectedItem = itemList.get(position);
                showEditDeleteDialog(selectedItem);
            }
        });
    }

    private void checkCurrentSmsPermission() {
        smsPermissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void loadAllItems() {
        itemList.clear();
        itemList.addAll(dbHelper.getAllItems());
        refreshDisplayList("All Inventory");
    }

    private void searchItems() {
        String searchText = editSearchItem.getText().toString().trim();

        if (TextUtils.isEmpty(searchText)) {
            Toast.makeText(this, "Enter an item name to search", Toast.LENGTH_SHORT).show();
            return;
        }

        itemList.clear();
        itemList.addAll(dbHelper.searchItemsByName(searchText));
        refreshDisplayList("Search Results");

        if (itemList.isEmpty()) {
            Toast.makeText(this, "No matching items found", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadLowStockItems() {
        itemList.clear();
        itemList.addAll(dbHelper.getLowStockItems(LOW_STOCK_THRESHOLD));
        refreshDisplayList("Low Stock Items");

        if (itemList.isEmpty()) {
            Toast.makeText(this, "No low-stock items found", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshDisplayList(String listTitle) {
        displayList.clear();

        for (DBHelper.Item item : itemList) {
            displayList.add(buildDisplayText(item));
        }

        adapter.notifyDataSetChanged();

        int totalItems = dbHelper.getTotalItemCount();
        Toast.makeText(this, listTitle + ": " + itemList.size() + " shown, " + totalItems + " total", Toast.LENGTH_SHORT).show();
    }

    private String buildDisplayText(DBHelper.Item item) {
        String displayText = "ID: " + item.getId()
                + "\n" + item.getName()
                + "\nQty: " + item.getQuantity();

        if (item.getQuantity() <= LOW_STOCK_THRESHOLD) {
            displayText += "\nLOW STOCK";
        }

        return displayText;
    }

    private void showAddItemDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        android.view.View dialogView = inflater.inflate(R.layout.dialog_add_edit_item, null);

        EditText editItemName = dialogView.findViewById(R.id.editItemName);
        EditText editItemQuantity = dialogView.findViewById(R.id.editItemQuantity);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(dialogView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

            saveButton.setOnClickListener(view -> {
                String name = editItemName.getText().toString().trim();
                Integer quantity = getValidatedQuantity(editItemQuantity.getText().toString().trim());

                if (!isValidItemName(name) || quantity == null) {
                    return;
                }

                if (dbHelper.addItem(name, quantity)) {
                    Toast.makeText(MainActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                    loadAllItems();
                    sendLowInventorySmsIfNeeded(name, quantity);
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    private void showEditDeleteDialog(DBHelper.Item item) {
        LayoutInflater inflater = LayoutInflater.from(this);
        android.view.View dialogView = inflater.inflate(R.layout.dialog_add_edit_item, null);

        EditText editItemName = dialogView.findViewById(R.id.editItemName);
        EditText editItemQuantity = dialogView.findViewById(R.id.editItemQuantity);

        editItemName.setText(item.getName());
        editItemQuantity.setText(String.valueOf(item.getQuantity()));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit or Delete Item")
                .setView(dialogView)
                .setPositiveButton("Update", null)
                .setNeutralButton("Delete", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button updateButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Button deleteButton = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);

            updateButton.setOnClickListener(view -> {
                String name = editItemName.getText().toString().trim();
                Integer quantity = getValidatedQuantity(editItemQuantity.getText().toString().trim());

                if (!isValidItemName(name) || quantity == null) {
                    return;
                }

                if (dbHelper.updateItem(item.getId(), name, quantity)) {
                    Toast.makeText(MainActivity.this, "Item updated", Toast.LENGTH_SHORT).show();
                    loadAllItems();
                    sendLowInventorySmsIfNeeded(name, quantity);
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            });

            deleteButton.setOnClickListener(view -> {
                if (dbHelper.deleteItem(item.getId())) {
                    Toast.makeText(MainActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                    loadAllItems();
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    private boolean isValidItemName(String name) {
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Enter item name", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (name.length() > MAX_ITEM_NAME_LENGTH) {
            Toast.makeText(this, "Item name must be 50 characters or less", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private Integer getValidatedQuantity(String quantityText) {
        if (TextUtils.isEmpty(quantityText)) {
            Toast.makeText(this, "Enter item quantity", Toast.LENGTH_SHORT).show();
            return null;
        }

        try {
            int quantity = Integer.parseInt(quantityText);

            if (quantity < 0) {
                Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                return null;
            }

            return quantity;
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void sendLowInventorySmsIfNeeded(String itemName, int quantity) {
        if (quantity <= LOW_STOCK_THRESHOLD) {
            sendLowInventorySms(itemName, quantity);
        }
    }

    private void sendLowInventorySms(String itemName, int quantity) {
        String phoneNumber = editPhoneNumber.getText().toString().trim();

        if (!smsPermissionGranted) {
            Toast.makeText(this, "SMS permission not granted. Inventory still saved.", Toast.LENGTH_LONG).show();
            return;
        }

        if (!isValidPhoneNumber(phoneNumber)) {
            return;
        }

        try {
            SmsManager smsManager;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsManager = getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }

            String message = "Low inventory alert: " + itemName
                    + " is low. Current quantity: " + quantity;

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, "Enter a phone number to send SMS alerts", Toast.LENGTH_LONG).show();
            return false;
        }

        if (!Patterns.PHONE.matcher(phoneNumber).matches()) {
            Toast.makeText(this, "Enter a valid phone number", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }
}