package com.example.projectthree360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "projectthree360.db";
    private static final int DATABASE_VERSION = 5;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD_HASH = "password_hash";
    public static final String COLUMN_PASSWORD_SALT = "password_salt";

    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_ITEM_QUANTITY = "item_quantity";

    private static final int SALT_LENGTH = 16;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COLUMN_PASSWORD_HASH + " TEXT NOT NULL, "
                + COLUMN_PASSWORD_SALT + " TEXT NOT NULL)";

        String createItemsTable = "CREATE TABLE " + TABLE_ITEMS + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT NOT NULL, "
                + COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createItemsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        if (username == null || password == null) {
            return false;
        }

        if (username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        String salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);

        if (hashedPassword == null) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username.trim());
        values.put(COLUMN_PASSWORD_HASH, hashedPassword);
        values.put(COLUMN_PASSWORD_SALT, salt);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean userExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username.trim()}
        )) {
            return cursor.getCount() > 0;
        }
    }

    public boolean checkUser(String username, String password) {
        if (username == null || password == null) {
            return false;
        }

        if (username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_PASSWORD_HASH + ", " + COLUMN_PASSWORD_SALT
                        + " FROM " + TABLE_USERS
                        + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username.trim()}
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }

            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD_HASH));
            String storedSalt = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD_SALT));
            String enteredHash = hashPassword(password, storedSalt);

            if (enteredHash == null) {
                return false;
            }

            return secureHashCompare(storedHash, enteredHash);
        }
    }

    public boolean addItem(String itemName, int quantity) {
        if (!isValidItemData(itemName, quantity)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName.trim());
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_ITEMS, null, values);
        return result != -1;
    }

    public boolean updateItem(int itemId, String itemName, int quantity) {
        if (!isValidItemData(itemName, quantity)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName.trim());
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        int result = db.update(
                TABLE_ITEMS,
                values,
                COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );

        return result > 0;
    }

    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_ITEMS,
                COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );

        return result > 0;
    }

    public ArrayList<Item> getAllItems() {
        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " ORDER BY LOWER(" + COLUMN_ITEM_NAME + ") ASC, "
                        + COLUMN_ITEM_QUANTITY + " ASC",
                null
        )) {
            addCursorItemsToList(cursor, itemList);
        }

        return itemList;
    }

    public ArrayList<Item> searchItemsByName(String searchText) {
        if (searchText == null || searchText.trim().isEmpty()) {
            return getAllItems();
        }

        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String searchPattern = "%" + searchText.trim() + "%";

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " WHERE " + COLUMN_ITEM_NAME + " LIKE ?"
                        + " ORDER BY LOWER(" + COLUMN_ITEM_NAME + ") ASC, "
                        + COLUMN_ITEM_QUANTITY + " ASC",
                new String[]{searchPattern}
        )) {
            addCursorItemsToList(cursor, itemList);
        }

        return itemList;
    }

    public ArrayList<Item> getLowStockItems(int threshold) {
        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS
                        + " WHERE " + COLUMN_ITEM_QUANTITY + " <= ?"
                        + " ORDER BY " + COLUMN_ITEM_QUANTITY + " ASC, LOWER(" + COLUMN_ITEM_NAME + ") ASC",
                new String[]{String.valueOf(threshold)}
        )) {
            addCursorItemsToList(cursor, itemList);
        }

        return itemList;
    }

    public int getTotalItemCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_ITEMS,
                null
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        }

        return 0;
    }

    private void addCursorItemsToList(Cursor cursor, ArrayList<Item> itemList) {
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
                itemList.add(new Item(id, name, quantity));
            } while (cursor.moveToNext());
        }
    }

    private boolean isValidItemData(String itemName, int quantity) {
        return itemName != null && !itemName.trim().isEmpty() && quantity >= 0;
    }

    private String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            String saltedPassword = salt + password;
            byte[] hash = messageDigest.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private boolean secureHashCompare(String storedHash, String enteredHash) {
        byte[] storedBytes = storedHash.getBytes(StandardCharsets.UTF_8);
        byte[] enteredBytes = enteredHash.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(storedBytes, enteredBytes);
    }

    public static class Item {
        private final int id;
        private final String name;
        private final int quantity;

        public Item(int id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}