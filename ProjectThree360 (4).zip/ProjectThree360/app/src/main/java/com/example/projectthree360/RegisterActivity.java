package com.example.projectthree360;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MIN_PASSWORD_LENGTH = 8;

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonRegister;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DBHelper(this);

        editUsername = findViewById(R.id.editUsernameRegister);
        editPassword = findViewById(R.id.editPasswordRegister);
        buttonRegister = findViewById(R.id.buttonRegisterUser);

        buttonRegister.setOnClickListener(view -> registerUser());
    }

    private void registerUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (!isValidRegistrationInput(username, password)) {
            return;
        }

        if (dbHelper.userExists(username)) {
            Toast.makeText(RegisterActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.addUser(username, password)) {
            Toast.makeText(RegisterActivity.this, "Account created", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidRegistrationInput(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(RegisterActivity.this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (username.length() < MIN_USERNAME_LENGTH) {
            Toast.makeText(RegisterActivity.this, "Username must be at least 3 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.length() < MIN_PASSWORD_LENGTH) {
            Toast.makeText(RegisterActivity.this, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}